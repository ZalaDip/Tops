import scrapy
from ..items import QutesTutorialItem

class QuotesSpider(scrapy.Spider):
    name = 'quotes'
    start_urls = [
        'https://quotes.toscrape.com/'
    ]
    def parse(self,response):
        all_div_quotes = response.css('div.quote')
        items = QutesTutorialItem()
        
        for i in all_div_quotes:
            quotes = i.css('span.text::text').extract()
            author = i.css('.author::text').extract()
            tags = i.css('.tag::text').extract()
        
            items['quotes'] = quotes
            items['author'] = author
            items['tags'] = tags
        
            yield items
        next_page = response.css("li.next a::attr(href)").get()
        if next_page:
            yield response.follow(next_page, callback= self.parse)